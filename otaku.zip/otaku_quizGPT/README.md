# Otaku Quizz GPT

This is a AI based game that generate a quiz based on anime name. Multiplayer only game with two player (for now).

## Live on

## Features

## Technologies

## TODO/DONE
<ul>
    <li>UI of join a game</li>
    <li>UI of create a game</li>
    <li>UI of the game</li>
    <li>UI of game result</li>
    <li>Add song and game icons</li>
</ul>

## Author


