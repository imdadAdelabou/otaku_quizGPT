import joinAGameILL from "./joinAGame.svg";
import createAGameILL from "./createAGame.svg";
import audioOnIcon from "./audioOnIcon.svg";
import audioOffIcon from "./audioOffIcon.svg";
import magicCliffAudio from "./audios/magicCliffAudio.ogg";

export {
  joinAGameILL,
  createAGameILL,
  audioOnIcon,
  audioOffIcon,
  magicCliffAudio,
};
