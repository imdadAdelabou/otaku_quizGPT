import "../index.css";

function ChooseOption({ img, title, alt }) {
  return (
    <div
      className={`w-72 h-72 border border-cyan-200 cursor-pointer rounded-md bg-black-gradient box-shadow hover:border-green-300`}
    >
      <img src={img} className="w-[190px] h-[190px] m-auto" alt={alt} />
      <h3 className="text-white font-poppins font-semibold text-[18px] text-center">
        {title}
      </h3>
    </div>
  );
}

export default ChooseOption;
