function CustomBtn({ content, onClick }) {
  return (
    <button
      onClick={onClick}
      className="font-poppins text-white block bg-dimBlue w-full h-[50px] rounded-lg bg-blue-500"
    >
      {content}
    </button>
  );
}

export default CustomBtn;
