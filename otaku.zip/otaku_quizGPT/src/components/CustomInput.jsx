import "../index.css";

function CustomInput({ placeHolder, onChange, value, type = "text", style }) {
  return (
    <input
      placeholder={placeHolder}
      onChange={onChange}
      value={value}
      type={type}
      className="rounded-sm text-white bg-black-gradient text-center border outline-none focus:border-blue-500 font-poppins"
      style={style}
    />
  );
}

export default CustomInput;
