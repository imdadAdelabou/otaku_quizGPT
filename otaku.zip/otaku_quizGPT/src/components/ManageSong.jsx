import useSound from "use-sound";
import { magicCliffAudio, audioOnIcon, audioOffIcon } from "../assets";
import { useState } from "react";

function ManageSong() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [playSound, { pause }] = useSound(magicCliffAudio, {
    interrupt: false,
  });

  const handleClick = () => {
    setIsPlaying((prevState) => !prevState);
    if (isPlaying) {
      pause();
      return;
    }
    playSound();
  };

  return (
    <div className="">
      <img
        src={isPlaying ? audioOnIcon : audioOffIcon}
        className="w-[40px] h-[40px] absolute right-0 m-4 cursor-pointer"
        onClick={handleClick}
      />
    </div>
  );
}

export default ManageSong;
