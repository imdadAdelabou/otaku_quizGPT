import { createAGameILL, joinAGameILL } from "../assets";

const createGameViewState = {
  initialState: "INITIAL",
  loading: "LOADING",
  inviteUserView: "INVITE_USER_VIEW",
};

const optionsFr = [
  {
    img: joinAGameILL,
    title: "Rejoindre une partie",
    alt: "joystick",
    path: "",
  },
  {
    img: createAGameILL,
    title: "Créer une partie",
    alt: "joystick",
    path: "/create-a-game",
  },
];

const appContent = {
  createGameLabel: "Créer une partie et inviter un joueur",
  descriptionText:
    "Avec otaku_QuizGPT, vous avez la possibilité de générer une série de questions/réponses sur un animé afin de tester entre amis vos connaissances sur cet animé. Le quiz est généré par ChatGPT.",
  promptToSendLabel: "Prompt :",
  generateQuizLabel: "Génère un quiz de ",
  numberOfQuestionLabel: "10",
  questionsLabel: " questions ",
  onAnimeNameLabel: "sur l'anime ",
  animeNameLabel: "nom de l'anime",
  withMultipleAnswerChoice:
    " avec plusieurs choix de réponse pour chaque question.",
  moreDetailForPrompt:
    "Vous pouvez donner plus de contextes au prompt ici !!!. À vous de jouer. (optionnel).",
  launchLabel: "Valider",
};

const tagsFr = ["#Temps-réel", "#Multijoueur"];

export { optionsFr, appContent, tagsFr, createGameViewState };
