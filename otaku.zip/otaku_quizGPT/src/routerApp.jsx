/* eslint-disable react/jsx-key */
import {
  Route,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import Home from "./views/Home";
import CreateAGame from "./views/CreateAGame";

const routerApp = createBrowserRouter(
  createRoutesFromElements([
    <Route path="/" element={<Home />} />,
    <Route path="/create-a-game" element={<CreateAGame />} />,
  ])
);

export default routerApp;
