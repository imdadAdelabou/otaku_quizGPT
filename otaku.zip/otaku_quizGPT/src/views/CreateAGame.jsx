import { appContent, tagsFr } from "../constants";
import styles from "../style";
import "../index.css";
import CustomInput from "../components/CustomInput";
import CustomBtn from "../components/CustomBtn";

function CreateAGame() {
  return (
    <div
      className={`bg-primary w-full h-[100vh] ${styles.flexCenter} overflow-hidden font-poppins`}
    >
      <div className="">
        <h1 className="font-poppins font-bold text-gradient text-[24px] leading-7">
          {appContent.createGameLabel}
        </h1>
        <p className="text-[#A8A8A8] w-[420px] text-[14px] mt-2 ">
          ( {appContent.descriptionText} )
        </p>
        <div className="mt-2 mb-8">
          {tagsFr.map((tag, index) => (
            <span
              key={index}
              className="text-white bg-secondary rounded-full p-2 text-[10px] bg-opacity-5 mr-2"
            >
              {tag}
            </span>
          ))}
        </div>
        <h3 className="text-white font-bold">{appContent.promptToSendLabel}</h3>
        <p className="text-white w-[470px]">
          {appContent.generateQuizLabel}{" "}
          <CustomInput
            type="number"
            style={{ height: 40, width: 40 }}
            placeHolder={appContent.numberOfQuestionLabel}
          />
          {appContent.questionsLabel} {appContent.onAnimeNameLabel}
          <CustomInput placeHolder={appContent.animeNameLabel} />
          {appContent.withMultipleAnswerChoice}
        </p>
        <textarea
          className="mt-4 bg-black-gradient w-[450px] text-white p-4 rounded-md border h-[100px] outline-none focus:border-blue-500 font-poppins mb-8"
          placeholder={appContent.moreDetailForPrompt}
        ></textarea>
        <CustomBtn content={appContent.launchLabel}></CustomBtn>
      </div>
    </div>
  );
}

export default CreateAGame;
