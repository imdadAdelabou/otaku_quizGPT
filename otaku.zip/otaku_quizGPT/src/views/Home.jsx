import styles from "../style";
import ManageSong from "../components/ManageSong";
import { optionsFr } from "../constants";
import ChooseOption from "../components/ChooseOption";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div className={`bg-primary w-full h-[100vh] overflow-hidden`}>
      <ManageSong />

      <div className={`${styles.flexCenter} h-[90%]`}>
        <section className="block justify-center gap-20 md:flex">
          {optionsFr.map((option, i) => (
            <li key={i}>
              <Link to={option.path}>
                <ChooseOption img={option.img} title={option.title} />
              </Link>
            </li>
          ))}
        </section>
      </div>
    </div>
  );
}

export default Home;
