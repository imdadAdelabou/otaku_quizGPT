import { createSlice } from "@reduxjs/toolkit";
import { createGameViewState } from "../../../constants";


const createGameSlice = createSlice({
    name: "createGame",
    initialState: {
        currentPageState: createGameViewState.initialState,
    },
    reducers: {},
    extraReducers: {},
  });

export default createGameSlice.reducer;